#include <sol/sol.hpp>
#include <vector>
#include <string>

// ---------- adatszerkezetek ----------
struct Wall { float x1,y1,x2,y2; };
struct Door { float x,y,width,height; std::string key; };
struct Key  { float x,y; std::string color; };

// ---------- level ----------
struct Level {
    std::vector<Wall> walls;
    std::vector<Door> doors;
    std::vector<Key>  keys;

    bool loadFromLua(const std::string& fileName) {
        sol::state lua;
        lua.open_libraries(sol::lib::base, sol::lib::table);
        lua.script_file(fileName);

        walls = lua.get<sol::as_table_t<std::vector<Wall>>>("walls");
        doors = lua.get<sol::as_table_t<std::vector<Door>>>("doors");
        keys  = lua.get<sol::as_table_t<std::vector<Key>>>("keys");
        return true;
    }
};

// ---------- main.cpp végére ----------
int main()
{
    Level lvl;
    if (lvl.loadFromLua("level1.lua"))
        std::cout << "Level loaded OK\n";
    else
        std::cout << "Load failed\n";
    return 0;
}