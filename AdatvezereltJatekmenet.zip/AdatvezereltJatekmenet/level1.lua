walls = {
    {x1=0,  y1=0,  x2=400, y2=0},
    {x1=400,y1=0,  x2=400, y2=300},
    {x1=400,y1=300,x2=0,   y2=300},
    {x1=0,  y1=300,x2=0,   y2=0}
}

doors = {
    {x=200, y=0, width=50, height=10, key="red"}
}

keys = {
    {x=100, y=150, color="red"}
}