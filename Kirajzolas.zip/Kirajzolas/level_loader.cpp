#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

struct Wall {
    float x, y, width, height;
};

struct Door {
    float x, y, width, height;
    bool locked;
};

struct Key {
    float x, y;
};

struct Level {
    std::vector<Wall> walls;
    std::vector<Door> doors;
    std::vector<Key> keys;
};

Level LoadLevel(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        throw std::runtime_error("Nem sikerült megnyitni a fájlt: " + filename);
    }

    json data;
    file >> data;
    Level level;

    // Falak beolvasása
    for (const auto& w : data["walls"]) {
        level.walls.push_back({
            w["x"], w["y"], w["width"], w["height"]
        });
    }

    // Ajtók beolvasása
    for (const auto& d : data["doors"]) {
        level.doors.push_back({
            d["x"], d["y"], d["width"], d["height"], d["locked"]
        });
    }

    // Kulcsok beolvasása
    for (const auto& k : data["keys"]) {
        level.keys.push_back({ k["x"], k["y"] });
    }

    return level;
}

int main() {
    try {
        Level level = LoadLevel("map.json");
        std::cout << "Betöltött falak: " << level.walls.size() << "\n";
        std::cout << "Betöltött ajtók: " << level.doors.size() << "\n";
        std::cout << "Betöltött kulcsok: " << level.keys.size() << "\n";
    }
    catch (const std::exception& e) {
        std::cerr << "Hiba: " << e.what() << std::endl;
    }

    return 0;
}
