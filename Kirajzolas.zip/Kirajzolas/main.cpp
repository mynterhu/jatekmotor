#include <SDL3/SDL.h>
#include <nlohmann/json.hpp>
#include <fstream>
#include <iostream>
#include <vector>

using json = nlohmann::json;

struct Wall
{
    float x, y, w, h;
};
struct Door
{
    float x, y, w, h;
    bool locked;
};
struct Key
{
    float x, y;
};
struct Player
{
    float x, y;
    float speed;
};

struct Level
{
    std::vector<Wall> walls;
    std::vector<Door> doors;
    std::vector<Key> keys;
};

Level LoadLevel(const std::string &path)
{
    std::ifstream file(path);
    if (!file.is_open())
        throw std::runtime_error("Nem található: " + path);

    json data;
    file >> data;
    Level level;

    for (auto &w : data["walls"])
        level.walls.push_back({w["x"], w["y"], w["width"], w["height"]});

    for (auto &d : data["doors"])
        level.doors.push_back({d["x"], d["y"], d["width"], d["height"], d["locked"]});

    for (auto &k : data["keys"])
        level.keys.push_back({k["x"], k["y"]});

    return level;
}

int main(int, char **)
{
    if (!SDL_Init(SDL_INIT_VIDEO))
    {
        std::cerr << "SDL hiba: " << SDL_GetError() << std::endl;
        return 1;
    }

    SDL_Window *window = SDL_CreateWindow("Edge Reversal - Hona Engine", 800, 600, SDL_WINDOW_RESIZABLE);
    SDL_Renderer *renderer = SDL_CreateRenderer(window, nullptr);

    Level level = LoadLevel("map.json");

    Player player = {60, 60, 2.5f};

    bool running = true;
    Uint64 lastTime = SDL_GetTicks();
    SDL_Event e;

    while (running)
    {
        while (SDL_PollEvent(&e))
        {
            if (e.type == SDL_EVENT_QUIT)
                running = false;
        }

        Uint64 currentTime = SDL_GetTicks();
        float deltaTime = (currentTime - lastTime) / 1000.0f; // másodpercekben
        lastTime = currentTime;

        const bool *state = SDL_GetKeyboardState(nullptr);

        float oldX = player.x;
        float oldY = player.y;

        if (state[SDL_SCANCODE_W])
            player.y -= player.speed + deltaTime;
        if (state[SDL_SCANCODE_S])
            player.y += player.speed + deltaTime;
        if (state[SDL_SCANCODE_A])
            player.x -= player.speed + deltaTime;
        if (state[SDL_SCANCODE_D])
            player.x += player.speed + deltaTime;

        SDL_FRect playerRect = {player.x, player.y, 20, 20};

        auto CheckCollision = [](const SDL_FRect &a, const SDL_FRect &b)
        {
            return (a.x < b.x + b.w && a.x + a.w > b.x &&
                    a.y < b.y + b.h && a.y + a.h > b.y);
        };

        struct Wall
        {
            float x, y, w, h;
        }; // most már van w és h

        bool CircleSegmentCollision(float cx, float cy, float r,
                                    float x1, float y1, float x2, float y2);
        // Ütközés falakkal
        for (auto &w : level.walls)
        {
            SDL_FRect wallRect = {w.x, w.y, w.w, w.h};
            if (CheckCollision(playerRect, wallRect))
            {
                // visszaállítjuk az előző pozíciót
                player.x = oldX;
                player.y = oldY;
                break;
            }
        }

        SDL_SetRenderDrawColor(renderer, 10, 10, 10, 255); // háttér (sötétszürke)
        SDL_RenderClear(renderer);

        // Falak (szürke)
        SDL_SetRenderDrawColor(renderer, 150, 150, 150, 255);
        for (auto &w : level.walls)
        {
            SDL_FRect rect = {w.x, w.y, w.w, w.h};
            SDL_RenderFillRect(renderer, &rect);
        }

        // Ajtók (piros, ha zárva, zöld, ha nyitva)
        for (auto &d : level.doors)
        {
            if (d.locked)
                SDL_SetRenderDrawColor(renderer, 255, 50, 50, 255);
            else
                SDL_SetRenderDrawColor(renderer, 50, 255, 50, 255);
            SDL_FRect rect = {d.x, d.y, d.w, d.h};
            SDL_RenderFillRect(renderer, &rect);
        }

        // Kulcsok (sárga)
        SDL_SetRenderDrawColor(renderer, 255, 255, 0, 255);
        for (auto &k : level.keys)
        {
            SDL_FRect rect = {k.x, k.y, 10, 10};
            SDL_RenderFillRect(renderer, &rect);
        }

        // Játékos (kék)
        SDL_SetRenderDrawColor(renderer, 50, 150, 255, 255);
        SDL_FRect rect = {player.x, player.y, 20, 20};
        SDL_RenderFillRect(renderer, &rect);

        SDL_RenderPresent(renderer);
        SDL_Delay(16); // kb. 60 FPS
    }

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}
