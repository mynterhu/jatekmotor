#include <SDL3/SDL.h>
#include <iostream>

struct Rect {
    float x, y, w, h;
};

bool checkCollision(const Rect& a, const Rect& b) {
    return (a.x < b.x + b.w &&
            a.x + a.w > b.x &&
            a.y < b.y + b.h &&
            a.y + a.h > b.y);
}

int main() {
    if (!SDL_Init(SDL_INIT_VIDEO)) {
        std::cerr << "SDL init error: " << SDL_GetError() << "\n";
        return 1;
    }

    const int SCREEN_WIDTH = 800;
    const int SCREEN_HEIGHT = 600;

    // Pálya méret
    const int WORLD_WIDTH = 2000;
    const int WORLD_HEIGHT = 1500;

    SDL_Window* window = SDL_CreateWindow("Camera Follow Example", SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_RESIZABLE);
    SDL_Renderer* renderer = SDL_CreateRenderer(window, nullptr);

    Rect player{100, 100, 40, 40};
    Rect key{300, 200, 20, 20};
    Rect door{1800, 1200, 50, 100};

    bool hasKey = false;
    bool doorOpen = false;

    bool running = true;
    SDL_Event e;
    const float speed = 250.0f;
    Uint64 lastTime = SDL_GetTicks();

    // Kamera
    SDL_FRect camera{0, 0, (float)SCREEN_WIDTH, (float)SCREEN_HEIGHT};

    while (running) {
        Uint64 current = SDL_GetTicks();
        float deltaTime = (current - lastTime) / 1000.0f;
        lastTime = current;

        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_EVENT_QUIT)
                running = false;
        }

        const bool* keys = SDL_GetKeyboardState(nullptr);
        if (keys[SDL_SCANCODE_ESCAPE]) running = false;
        if (keys[SDL_SCANCODE_UP]) player.y -= speed * deltaTime;
        if (keys[SDL_SCANCODE_DOWN]) player.y += speed * deltaTime;
        if (keys[SDL_SCANCODE_LEFT]) player.x -= speed * deltaTime;
        if (keys[SDL_SCANCODE_RIGHT]) player.x += speed * deltaTime;

        // Ne menjen ki a világ szélére
        if (player.x < 0) player.x = 0;
        if (player.y < 0) player.y = 0;
        if (player.x + player.w > WORLD_WIDTH) player.x = WORLD_WIDTH - player.w;
        if (player.y + player.h > WORLD_HEIGHT) player.y = WORLD_HEIGHT - player.h;

        // Kulcs felvétele
        if (!hasKey && checkCollision(player, key)) {
            hasKey = true;
            std::cout << "Kulcs felvéve!\n";
        }

        // Ajtó nyitása
        if (hasKey && !doorOpen && checkCollision(player, door)) {
            doorOpen = true;
            std::cout << "Ajtó kinyitva!\n";
        }

        // Kamera követés
        camera.x = player.x + player.w / 2 - camera.w / 2;
        camera.y = player.y + player.h / 2 - camera.h / 2;

        // Ne menjen ki a világ szélére a kamera
        if (camera.x < 0) camera.x = 0;
        if (camera.y < 0) camera.y = 0;
        if (camera.x + camera.w > WORLD_WIDTH) camera.x = WORLD_WIDTH - camera.w;
        if (camera.y + camera.h > WORLD_HEIGHT) camera.y = WORLD_HEIGHT - camera.h;

        // Rajzolás
        SDL_SetRenderDrawColor(renderer, 30, 30, 30, 255);
        SDL_RenderClear(renderer);

        // Egyszerű háttér (világ)
        SDL_SetRenderDrawColor(renderer, 50, 50, 50, 255);
        for (int x = 0; x < WORLD_WIDTH; x += 100) {
            for (int y = 0; y < WORLD_HEIGHT; y += 100) {
                SDL_FRect tile = {(float)x - camera.x, (float)y - camera.y, 98, 98};
                SDL_RenderRect(renderer, &tile);
            }
        }

        // Játékos
        SDL_FRect pRect{player.x - camera.x, player.y - camera.y, player.w, player.h};
        SDL_SetRenderDrawColor(renderer, 0, 128, 255, 255);
        SDL_RenderFillRect(renderer, &pRect);

        // Kulcs
        if (!hasKey) {
            SDL_FRect kRect{key.x - camera.x, key.y - camera.y, key.w, key.h};
            SDL_SetRenderDrawColor(renderer, 255, 220, 0, 255);
            SDL_RenderFillRect(renderer, &kRect);
        }

        // Ajtó
        SDL_FRect dRect{door.x - camera.x, door.y - camera.y, door.w, door.h};
        if (doorOpen)
            SDL_SetRenderDrawColor(renderer, 0, 200, 0, 255);
        else
            SDL_SetRenderDrawColor(renderer, 200, 0, 0, 255);
        SDL_RenderFillRect(renderer, &dRect);

        SDL_RenderPresent(renderer);
    }

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}
