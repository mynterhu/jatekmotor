#include <SFML/Graphics.hpp>
#include <cmath>
#include <vector>

struct Ball {
    sf::Vector2f pos;
    sf::Vector2f vel;
    float radius;
    sf::Color color;

    Ball(float x, float y, float vx, float vy, float r, sf::Color c)
        : pos(x, y), vel(vx, vy), radius(r), color(c) {}

    void move(float w, float h) {
        pos += vel;
        if (pos.x - radius < 0.f)       { pos.x = radius;        vel.x = -vel.x; }
        if (pos.x + radius > w)         { pos.x = w - radius;    vel.x = -vel.x; }
        if (pos.y - radius < 0.f)       { pos.y = radius;        vel.y = -vel.y; }
        if (pos.y + radius > h)         { pos.y = h - radius;    vel.y = -vel.y; }
    }

    void draw(sf::RenderWindow& win) const {
        sf::CircleShape shape(radius);
        shape.setFillColor(color);
        shape.setOrigin({radius, radius});   // SFML 3: Vector2f
        shape.setPosition(pos);
        win.draw(shape);
    }
};

void collide(Ball& a, Ball& b) {
    sf::Vector2f d = a.pos - b.pos;
    float dist = std::sqrt(d.x * d.x + d.y * d.y);
    float minDist = a.radius + b.radius;

    if (dist < minDist && dist > 0.f) {
        sf::Vector2f n = d / dist;
        float p = (a.vel.dot(n) - b.vel.dot(n)); // = vr · n
        a.vel -= p * n;
        b.vel += p * n;

        float overlap = 0.5f * (minDist - dist + 1.f);
        a.pos += n * overlap;
        b.pos -= n * overlap;
    }
}

int main() {
    constexpr unsigned WIDTH = 800, HEIGHT = 600;
    sf::RenderWindow window(sf::VideoMode({WIDTH, HEIGHT}),
                            "Mozgó objektumok ütközéssel");
    window.setFramerateLimit(60);

    std::vector<Ball> balls{
        {200, 300, 2.5f, 1.7f, 30, sf::Color::Red},
        {400, 400, -2.0f, 2.3f, 30, sf::Color::Green},
        {600, 200, -2.5f, -1.5f, 30, sf::Color::Blue}
    };

    while (window.isOpen()) {
        while (const std::optional ev = window.pollEvent()) {
            if (ev->is<sf::Event::Closed>())
                window.close();
        }

        for (auto& b : balls) b.move(WIDTH, HEIGHT);
        for (std::size_t i = 0; i < balls.size(); ++i)
            for (std::size_t j = i + 1; j < balls.size(); ++j)
                collide(balls[i], balls[j]);

        window.clear({20, 20, 30});
        for (const auto& b : balls) b.draw(window);
        window.display();
    }
}